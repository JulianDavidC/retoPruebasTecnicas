package com.floristeriamundoflor.userInterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class FloristeriaMundoFlorAgradecimientosUI {
  public static final Target BOX_PRODUCTOS = Target.the("CAJA CON LOS PRODUCTOS")
          .locatedBy("//*[@id='content']");

  public static final Target LBL_TITULO= Target.the("TITULO  PAGINA")
          .locatedBy("//h1[contains(text(),'Agradecimientos')]");

  public static final Target LBL_PRODUCTO1= Target.the("PRODUCTO 1")
          .locatedBy("//*[@id='content']/div[2]/div/div[1]/div/div[1]/figure/a/img");

  public static final Target BTN_PRODUCTO1= Target.the("PRODUCTO 1")
          .locatedBy("//*[@id='content']/div[2]/div/div[1]/div/div[1]/figure/div/div[1]/a/span");

  public static final Target BTN_VOLVER= Target.the("BOTON PARA VOLVER ")
          .locatedBy("//a[@href='https://www.floristeriamundoflor.com/product-category/agradecimientos/']");


  public static final Target LBL_PRODUCTO2= Target.the("PRODUCTO 2")
          .locatedBy("//*[@id='content']/div[2]/div/div[2]/div/div[1]/figure/a/img");

  public static final Target BTN_PRODUCTO2= Target.the("PRODUCTO 2")
          .locatedBy("//*[@id='content']/div[2]/div/div[2]/div/div[1]/figure/div/div[1]/a/span");

  public static final Target LBL_PRODUCTOCARRITO1= Target.the("VALIDAR PRODUCTO 1 EN EL CARRITO")
          .locatedBy("//td/a[@href='https://www.floristeriamundoflor.com/product/mdf-00015/'][contains(text(),'MDF 00015')]");

  public static final Target LBL_PRODUCTOCARRITO2= Target.the("VALIDAR PRODUCTO 2 EN EL CARRITO")
          .locatedBy("//td/a[@href='https://www.floristeriamundoflor.com/product/mdf-00015/'][contains(text(),'MDF 00015')]");
}





