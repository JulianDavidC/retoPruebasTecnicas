package com.floristeriamundoflor.userInterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class FloristeriaMundoFlorHomeUI {

  public static final Target LBL_CATEGORIA = Target.the("LABEL NOMBRE DE LA CATEGORIA")
          .locatedBy("//*[@id='menu-item-2794']/a");
}
