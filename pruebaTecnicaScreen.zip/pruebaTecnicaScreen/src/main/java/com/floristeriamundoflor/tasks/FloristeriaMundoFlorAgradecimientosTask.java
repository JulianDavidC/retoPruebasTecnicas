package com.floristeriamundoflor.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.targets.Target;

import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.BTN_PRODUCTO1;
import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.LBL_PRODUCTO1;
import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.BTN_VOLVER;
import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.LBL_PRODUCTO2;
import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.BTN_PRODUCTO2;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class FloristeriaMundoFlorAgradecimientosTask implements Task {


  @Override
  public <T extends Actor> void performAs(T actor) {
    actor.attemptsTo(
            MoveMouse.to(LBL_PRODUCTO1),
            Click.on(BTN_PRODUCTO1),
            Click.on(BTN_VOLVER),
            MoveMouse.to(LBL_PRODUCTO2),
            Click.on(BTN_PRODUCTO2)
    );
  }

  public static Performable agradecimientosTask() {
    return instrumented(FloristeriaMundoFlorAgradecimientosTask.class);
  }
}

