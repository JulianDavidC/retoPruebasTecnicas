package com.floristeriamundoflor.stepDefinitions;

import com.floristeriamundoflor.tasks.FloristeriaMundoFlorAgradecimientosTask;
import com.floristeriamundoflor.tasks.FloristeriaMundoFlorHomeTask;
import io.cucumber.java.Before;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnlineCast;

import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.BOX_PRODUCTOS;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.*;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;
import static net.serenitybdd.screenplay.questions.WebElementQuestion.the;

public class ingresarCategoriaAgradecimientosStepDefinitions {
  private Actor actor;
  @Before
  public void setStage() {

    setTheStage(new OnlineCast());
  }
  @Dado("que estoy en la página principal de la tienda https:\\/\\/www.floristeriamundoflor.com\\/")
  public void queEstoyEnLaPáginaPrincipalDeLaTiendaHttpsWwwFloristeriamundoflorCom() {
    theActorCalled("Robot").wasAbleTo(Open.url("https://www.floristeriamundoflor.com/"));
  }
  @Cuando("selecciono la categoría Agradecimientos")
  public void seleccionoLaCategoría() {
    theActorInTheSpotlight().attemptsTo(FloristeriaMundoFlorHomeTask.homeTask());
  }
  @Entonces("se visualizarán los productos para esta categoría")
  public void seVisualizaránLosProductosParaEstaCategoría() {
    theActorCalled("Robot").should(seeThat(the(BOX_PRODUCTOS), isVisible()));
  }
}
