package com.floristeriamundoflor.stepDefinitions;

import com.floristeriamundoflor.tasks.FloristeriaMundoFlorAgradecimientosTask;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;

import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.LBL_TITULO;
import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.LBL_PRODUCTOCARRITO1;
import static com.floristeriamundoflor.userInterfaces.FloristeriaMundoFlorAgradecimientosUI.LBL_PRODUCTOCARRITO2;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;
import static net.serenitybdd.screenplay.questions.WebElementQuestion.the;

public class anadirProductoCarritoStepDefinition {
  @Dado("que estoy en la categoría Agradecimientos")
  public void queEstoyEnLaCategoríaAgradecimientos() {
    theActorCalled("Robot").should(seeThat(the(LBL_TITULO), isVisible()));
  }
  @Cuando("de clic en la opción Añadir al carrito")
  public void deClicEnLaOpciónAñadirAlCarrito() {
    theActorInTheSpotlight().attemptsTo(FloristeriaMundoFlorAgradecimientosTask.agradecimientosTask());
  }
  @Entonces("El producto se agregará al carrito de compras")
  public void elProductoSeAgregaráAlCarritoDeCompras() {
    theActorCalled("Robot").should(seeThat(the(LBL_PRODUCTOCARRITO1), isVisible()));
    theActorCalled("Robot").should(seeThat(the(LBL_PRODUCTOCARRITO2), isVisible()));
  }
}
