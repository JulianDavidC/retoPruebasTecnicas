package in.reqres.runners;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features/listarUsuario.feature",
        glue  = "in.reqres.stepDefinitions",
        snippets = CucumberOptions.SnippetType.CAMELCASE
)

public class ListarUsuariosRunner {
}
