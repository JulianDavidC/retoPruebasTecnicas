package in.reqres.stepDefinitions;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.IOException;

import static io.restassured.RestAssured.given;

public class ActualizarUsuarioStepDefinition {
  private Response response;
  private RequestSpecification request;
  File postBody = new File("src/main/java/in/reqres/utils/actualizarUsuario.json");
  @Dado("que tengo un ID de usuario existente")
  public void queTengoUnIDDeUsuarioExistente() {

    request = given()
            .baseUri("https://reqres.in")
            .basePath("/api/users")
            .header("Content-Type","application/json")
            .body(postBody);
  }
  @Cuando("realizo una solicitud PUT al endpoint \\/api\\/users\\/\\{id} con datos actualizados")
  public void realizoUnaSolicitudPUTAlEndpointApiUsersConDatosActualizados() {
    response = request
            .when()
            .put("/3");
  }
  @Entonces("la respuesta debe indicar que el usuario fue actualizado exitosamente con un estado de 200, y debe devolver los datos actualizados.")
  public void laRespuestaDebeIndicarQueElUsuarioFueActualizadoExitosamenteConUnEstadoDeYDebeDevolverLosDatosActualizados() {
    ObjectMapper objectMapper = new ObjectMapper();
    int statusCode = response.getStatusCode();
    String nombreResponse = response.jsonPath().getString("name");
    String trabajoResponse = response.jsonPath().getString("job");
    response.prettyPrint();
    response.then().statusCode(200);
    System.out.println("Se actualizo el nombre por " + nombreResponse +" y el Tabrajo por:"+trabajoResponse);
    System.out.println("El estatus de la peticion es " + statusCode + " Actualizacion correcta");
  }
}
