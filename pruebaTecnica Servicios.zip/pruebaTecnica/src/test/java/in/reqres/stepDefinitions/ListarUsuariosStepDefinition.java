package in.reqres.stepDefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class ListarUsuariosStepDefinition {
  private Response response;
  private RequestSpecification request;



  @Dado("que accedo al servicio de listar usuarios de ReqRes")
  public void queAccedoAlServicioDeListarUsuariosDeReqRes() {
     request = given()
            .baseUri("https://reqres.in")
            .basePath("/api/users");
  }
  @Cuando("realizo una solicitud GET al endpoint \\/api\\/users?page=2")
  public void realizoUnaSolicitudGETAlEndpointApiUsersPage() {

    response = request
            .when()
            .get("?page=2");

  }
  @Entonces("la respuesta debe contener la lista de usuarios en la página 2 y el estado de la respuesta debe ser 200.")
  public void laRespuestaDebeContenerLaListaDeUsuariosEnLaPáginaYElEstadoDeLaRespuestaDebeSer() {
    response.prettyPrint();
    response.then().body("page", equalTo(2));
    response.then().statusCode(200);
  }
}
