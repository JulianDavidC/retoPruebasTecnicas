package in.reqres.stepDefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;

import static io.restassured.RestAssured.given;

public class CrearUsuarioStepDefinition {
  private Response response;
  private RequestSpecification request;
  @Dado("que tengo los datos para crear un nuevo usuario")
  public void queTengoLosDatosParaCrearUnNuevoUsuario() {
    File postBody = new File("src/main/java/in/reqres/utils/crearUsuario.json");
    request = given()
            .baseUri("https://reqres.in")
            .basePath("/api/users")
            .header("Content-Type","application/json")
            .body(postBody);
  }
  @Cuando("realizo una solicitud POST al endpoint \\/api\\/users con los datos del usuario")
  public void realizoUnaSolicitudPOSTAlEndpointApiUsersConLosDatosDelUsuario() {
    response = request
            .when()
            .post();
  }
  @Entonces("Entonces la respuesta debe indicar que el usuario fue creado exitosamente con un estado de 201, y debe devolver el ID del usuario creado.")
  public void entoncesLaRespuestaDebeIndicarQueElUsuarioFueCreadoExitosamenteConUnEstadoDeYDebeDevolverElIDDelUsuarioCreado() {
    int statusCode = response.getStatusCode();
    response.prettyPrint();
    response.then().statusCode(201);
    System.out.println("El estatus de la peticion es " + statusCode + " Por lo tanto el usuario se creo de forma correcta");

  }
}
