package in.reqres.stepDefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

public class EliminarUsuariosStepDefition {
  private Response response;
  private RequestSpecification request;
  @Dado("que tengo un usuario existente")
  public void que_tengo_un_usuario_existente() {
    request = given()
            .baseUri("https://reqres.in")
            .basePath("/api/users");
  }
  @Cuando("realizo una solicitud DELETE al endpoint \\/api\\/users\\/{int}")
  public void realizo_una_solicitud_delete_al_endpoint_api_users(int id) {
    response = request
            .when()
            .delete(String.valueOf(id));
  }
  @Entonces("la respuesta debe devolver un estado de {int} , indicando que el usuario fue eliminado exitosamente.")
  public void la_respuesta_debe_devolver_un_estado_de_indicando_que_el_usuario_fue_eliminado_exitosamente(int statusCodeEsperado) {
    int statusCode = response.getStatusCode();
    if (statusCode == statusCodeEsperado){
      response.prettyPrint();
      response.then().statusCode(204);
      System.out.println("Eliminacion exitosa, codigo de respuesta " +statusCode);
    }else{
      System.out.println("Los estados no coinciden eliminacion incorrecta");
    }

  }

}
